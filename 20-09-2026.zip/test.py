kn_academy_batch_name = "   Ultimate Data Science & AI Engineer Bootcamp 3.0 "
print("jello")
12